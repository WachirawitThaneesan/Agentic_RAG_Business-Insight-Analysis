"""SQLAlchemy models for documents, chunks, and structured data."""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Text, DateTime, ForeignKey, JSON, Index, UniqueConstraint
)
from sqlalchemy.orm import DeclarativeBase, relationship
from pgvector.sqlalchemy import Vector


class Base(DeclarativeBase):
    pass


class Document(Base):
    """Represents an uploaded or scraped document."""
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, autoincrement=True)
    filename = Column(String(500), nullable=False)
    source_url = Column(String(2000), nullable=True)
    source_sha256 = Column(String(64), nullable=True)
    raw_text = Column(Text, nullable=True)
    doc_type = Column(String(50), default="pdf")  # pdf, image, html
    status = Column(String(50), default="pending")  # pending, processing, completed, partial, failed
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow,
                        onupdate=datetime.utcnow)

    chunks = relationship("Chunk", back_populates="document", cascade="all, delete-orphan")
    structured_data = relationship("StructuredData", back_populates="document", cascade="all, delete-orphan")
    pages = relationship("DocumentPage", back_populates="document", cascade="all, delete-orphan")


class DocumentPage(Base):
    """Durable PDF-page progress, independent of OCR artifacts and indexing."""
    __tablename__ = "document_pages"

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(Integer, ForeignKey("documents.id", ondelete="CASCADE"), nullable=False)
    page_number = Column(Integer, nullable=False)
    status = Column(String(32), nullable=False, default="pending")
    error_stage = Column(String(32), nullable=True)
    error_message = Column(Text, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    document = relationship("Document", back_populates="pages")

    __table_args__ = (
        UniqueConstraint("document_id", "page_number", name="uq_document_pages_document_page"),
        Index("ix_document_pages_document_id", "document_id"),
    )


class Chunk(Base):
    """A semantic chunk of a document with its embedding."""
    __tablename__ = "chunks"

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(Integer, ForeignKey("documents.id", ondelete="CASCADE"), nullable=False)
    chunk_index = Column(Integer, nullable=False)
    chunk_text = Column(Text, nullable=False)
    summary = Column(Text, nullable=True)  # LLM-generated summary
    token_count = Column(Integer, nullable=True)
    embedding = Column(Vector(1024), nullable=True)  # bge-m3 dimension
    metadata_ = Column("metadata", JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    document = relationship("Document", back_populates="chunks")

    __table_args__ = (
        Index("ix_chunks_document_id", "document_id"),
    )


class StructuredData(Base):
    """Long-format table data extracted from documents for Text-to-SQL."""
    __tablename__ = "structured_data"

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(Integer, ForeignKey("documents.id", ondelete="CASCADE"), nullable=False)
    table_name = Column(String(500), nullable=True)
    headers = Column(JSON, nullable=True)   # List of column names
    row_data = Column(JSON, nullable=False)  # JSONB row in long format
    row_index = Column(Integer, nullable=True)
    source_page = Column(Integer, nullable=True)
    unit = Column(String(100), nullable=True)
    source_provider = Column(String(40), nullable=True)
    source_sha256 = Column(String(64), nullable=True)
    quality_status = Column(String(40), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    document = relationship("Document", back_populates="structured_data")

    __table_args__ = (
        Index("ix_structured_data_document_id", "document_id"),
        Index("ix_structured_data_source_page", "document_id", "source_page"),
    )
